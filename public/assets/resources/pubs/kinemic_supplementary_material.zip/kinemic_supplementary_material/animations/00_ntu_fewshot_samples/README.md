# Real NTU few-shot samples

We provide side-by-side the real few-shot samples used in our paper.

* **Left column**: Raw kinect skeletons
* **Right column**: VIBE extracted SMPL skeletons (used for training)