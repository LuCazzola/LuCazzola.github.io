# Motion Composition

**Few examples of emergent motion composition at inference time**  
*Recommended*: visualize from [project page](https://lucazzola.github.io/publications/kinemic)

- **composition_1**  
  *Text prompt*: 'a person is jumping'  
  *Action ID*: 'stretch on self'  
  *Insight*: The sim starts in a crouched position, then raises both arms overhead while jumping simultaneously. The 'hands overhead' component is specifically highly present in 'stretch on self' motions.

- **composition_2**  
  *Text prompt*: 'a person throws punches'  
  *Action ID*: 'stretch on self'  
  *Insight*: The man begins to perform a punch/throw motion, which transitions into torso twists for the stretching component.

- **composition_3**  
  *Text prompt*: 'a person is jumping'  
  *Action ID*: 'stretch on self'  
  *Insight*: The generated motion blends jumping with stretching—arms extend overhead during the jump, combining both conditions seamlessly.
