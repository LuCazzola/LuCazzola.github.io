# Visualizing Kinetic Mining

**Recommended**: Visualize from [project page](https://lucazzola.github.io/publications/kinemic)

**Key examples**:

- **sidekick_extraction_1**  
  *Caption*: 'a man kicks with his left leg- first up, then to the left, then backwards'  
  *Target*: 'side kick'  
  *Insight*: In this example, the man performs multiple variations of kicks in the same source motion. The extracted window corresponds to 'left kicking' which is reasonably much more correlated to 'side kick' than other options.

- **stretch_extraction_1**  
  *Caption*: 'a person gracefully performs a contemporary dance.'  
  *Target*: 'stretch on self'  
  *Insight*: In this example, the person performs multiple dance moves in the same source motion. While caption description is arguably far from 'stretch on self', if isolated, some movements can be interpreted as a stretch type of movement. In this case, as most 'stretching movements' are upper body dominant we can see as highlighted section motion focuses on upper body stretch-like movements.

- **runspot_extraction_1**  
  *Caption*: 'a person marches in place, stands, and then runs in place.'  
  *Target*: 'run on the spot'  
  *Insight*: Here the character begins by marching in place, transitions to standing still, and finally engages in running in place. The extracted window captures the 'running in place' segment, which aligns closely with the target description 'run on the spot', it's clear how the 'fast pacing' of leg movements produces higher correlation with the target action compared to other segments relative to 'marching' especially.

- **sidekick_extraction_2**  
  *Caption*: 'the sim is dancing kicking both legs around.'  
  *Target*: 'side kick'  
  *Insight*: The character movement is rather chaotic, involving rapid leg kicks in various directions. Despite the overall randomness, there are brief moments where the character executes a kick that closely resembles a 'side kick'. The extracted window captures one of these instances, highlighting the segment where the leg movement aligns most closely with the target action 'side kick'.

- **stretch_extraction_2**  
  *Caption*: 'a person lowers himself into a yoga position.'  
  *Target*: 'stretch on self'  
  *Insight*: The person is performing a yoga movement, a pike specifically. Within this motion sequence, the section which is considered to be best aligned with 'stretch on self' refers to the segment where the full-pike position is held, emphasizing the stretch aspect of the movement.

- **runspot_extraction_2**  
  *Caption*: 'a person is running on a treadmill.'  
  *Target*: 'run on the spot'  
  *Insight*: Some lucky samples might be almost one-to-one correspondences. In this case, the entire source motion is correlated to the target action 'run on the spot', as both describe a running motion without significant spatial displacement.
