# Pre-trained MDM Generations (75 samples, 15 per file)

**Observations:**
1. **High diversity** across all action classes
2. **Kinematic inaccuracies** prominent in 'side kick' and 'stretch on self': kicks rarely execute true side motion
3. **Early termination artifacts**: motions initiate but truncate prematurely, as the pretrained model was never trained on short atomic NTU-like sequences (~2-3s)
